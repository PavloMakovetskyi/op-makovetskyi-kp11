﻿using System.Windows;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System;
using System.Windows.Controls;

namespace ConnectToSQLServer
{
    public partial class MainWindow : Window
    {
        string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;        
        SqlConnection connection = null;
        SqlCommand command;
        SqlDataAdapter adapter;

        public MainWindow()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            //MessageBox.Show(connectionString);
            ShowAllData();
        }
        
        private void ShowAllData()
        {
            GetAllClimbs();
            GetAlpinistsData();
            GetMountainsData();
            GetSmallestMountains();
        }

        private void GetAndDhowData(string SQLQuery, DataGrid dataGrid)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            command = new SqlCommand(SQLQuery, connection);
            adapter = new SqlDataAdapter(command);
            DataTable Table = new DataTable();
            adapter.Fill(Table);
            dataGrid.ItemsSource = Table.DefaultView;
            connection.Close();            
        }

        private void GetAllClimbs()
        {
            string sqlQ = "SELECT [ClimbID] AS Climb, [GroupID] AS [Group], MountainName AS Mountain, " +
                "startDate AS [Start], endDate AS [End] FROM Climbs";
            try
            {
                GetAndDhowData(sqlQ, ClimbsDG);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void GetAlpinistsData()
        {
            string sqlQ = "SELECT firstName AS [Name], lastName AS [Surname], [Address], Alpinists.GroupID AS [Group], Groups.MountainName FROM Alpinists " +
                "JOIN Groups ON Alpinists.GroupID = Groups.GroupID;";

            try
            {
                GetAndDhowData(sqlQ, AlpinistsDG);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void GetMountainsData()
        {
            string sqlQ = "SELECT * FROM Mountains;";
            try
            {
                GetAndDhowData(sqlQ, MountainsDG);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void GetSmallestMountains()
        {
            string sqlQ = "SELECT TOP 2 Mountains.[Name], Mountains.[Height] FROM Mountains " +
                "ORDER BY[Height] ASC";
            try
            {
                GetAndDhowData(sqlQ, SmallestMountainsDG);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void AddAlpBtn_Click(object sender, RoutedEventArgs e)
        {
            string name = AlpinistName.Text;
            string surname = AlpinistSurname.Text;
            string address = AddressBox.Text;
            int group = int.Parse(GroupNum.Text);

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                string sqlQ = "INSERT INTO Alpinists VALUES ('" + name + "', '" + surname + "', '" + address + "', " +
                "'" + group + "')";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }
        
        private void UpdateNameSurname_Click(object sender, RoutedEventArgs e)
        {
            string name = AlpinistName.Text;
            string surname = AlpinistSurname.Text;

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "UPDATE Alpinists SET firstName = '" + name + "', lastName = '" + surname + "' WHERE alpinistID = " +
                    "'" + int.Parse(IDBox.Text) + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void UpdateAddress_Click(object sender, RoutedEventArgs e)
        {
            
            string address = AddressBox.Text;

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "UPDATE Alpinists SET [Address] = '" + address + "' WHERE alpinistID = " +
                    "'" + int.Parse(IDBox.Text) + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void UpdateGroup_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "UPDATE Alpinists SET [GroupID] = '" + int.Parse(GroupNum.Text) + "' WHERE alpinistID = " +
                    "'" + int.Parse(IDBox.Text) + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void DeleteAlp_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "DELETE FROM Alpinists WHERE [AlpinistID] = '" + int.Parse(IDBox.Text) + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void AddMoun_Click(object sender, RoutedEventArgs e)
        {
            string name = MounName.Text;
            string height = MounHeight.Text;
            string country = MounCountry.Text;
            string area = MounArea.Text;

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "INSERT INTO Mountains VALUES ('" + name + "', '" + height + "', '" + country + "', " +
                "'" + area + "')";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string name = MounName.Text;
        

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "UPDATE Mountains SET [Name] = '" + name + "' WHERE [Name] = '" + MounNameID.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string height = MounHeight.Text;

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "UPDATE Mountains SET [Height] = '" + int.Parse(height) + "' WHERE [Name] = '" + MounNameID.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string country = MounCountry.Text;

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "UPDATE Mountains SET [Country] = '" + country + "' WHERE [Name] = '" + MounNameID.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            string region = MounCountry.Text;

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "UPDATE Mountains SET [Area] = '" + region + "' WHERE [Name] = '" + MounNameID.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "DELETE FROM Mountains WHERE [Name] = '" + MounNameID.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            string name = MounClimb.Text;
            string date1 = StartDate.Text;
            string date2 = EndDate.Text;
            int group = int.Parse(GroupNumber.Text);

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "INSERT INTO Climbs VALUES ('" + group + "', '" + name + "', '" + date1 + "', " +
                "'" + date2 + "')";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            string climbmoun = MounClimb.Text;

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "UPDATE Climbs SET MountainName = '" + climbmoun + "' WHERE [ClimbID] = '" + ClimbNum.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                string grcl = GroupNumber.Text;
                sqlC.Open();
                string sqlQ = "UPDATE Climbs SET GroupID = '" + int.Parse(grcl) + "' WHERE [GroupID] = '" + ClimbNum.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                string grcl = StartDate.Text;
                sqlC.Open();
                string sqlQ = "UPDATE Climbs SET [Start] = '" + grcl + "' WHERE [GroupID] = '" + ClimbNum.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                string grcl = EndDate.Text;
                sqlC.Open();
                string sqlQ = "UPDATE Climbs SET [End] = '" + int.Parse(grcl) + "' WHERE [GroupID] = '" + ClimbNum.Text + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            string name = GrMounID.Text;
            string climbID = GroupClimb.Text;

            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "INSERT INTO Groups VALUES ('" + int.Parse(climbID) + "', '" + name + "')";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                string grcl = GrMounID.Text;
                sqlC.Open();
                string sqlQ = "UPDATE Groups SET [MountainName] = '" + grcl + "' WHERE [GroupID] = '" + int.Parse(GrID.Text) + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "DELETE FROM Climbs WHERE [Name] = '" + int.Parse(ClimbNum.Text) + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                string grcl = GroupClimb.Text;
                sqlC.Open();
                string sqlQ = "UPDATE Groups SET [ClimbID] = '" + grcl + "' WHERE [GroupID] = '" + int.Parse(GrID.Text) + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }

        private void Button_Click_14(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlC = new SqlConnection(connectionString))
            {
                sqlC.Open();
                string sqlQ = "DELETE FROM Groups WHERE [Name] = '" + int.Parse(GrID.Text) + "'";
                SqlCommand Comm = new SqlCommand(sqlQ, sqlC);
                Comm.ExecuteNonQuery();
                ShowAllData();
            }
        }
    }
}