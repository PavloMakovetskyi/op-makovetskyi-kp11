﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using Microsoft.Data.SqlClient;

namespace Prac._03
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string Connection = "Server=.\\SQLEXPRESS; Database=PassAuthDB; Trusted_Connection = True; TrustServerCertificate=Yes";
        
        public MainWindow()
        {
            InitializeComponent();

            SqlConnection con = new SqlConnection(Connection);

            con.Open();
   
            string sqlQ = "IF NOT EXISTS(SELECT * FROM MainTable WHERE [Login] = 'ADMIN')\n" +
                          "BEGIN\n" + "INSERT INTO MainTable VALUES('Pavlo', 'Makovetskyi', 'ADMIN', 'admin', 1, 0);\n" +
                          "END";
            SqlCommand sqlC = new SqlCommand(sqlQ, con);
            sqlC.ExecuteNonQuery();

            con.Close();
            
        }

        private void AdminMode_Click(object sender, RoutedEventArgs e)
        {
            Administration administration = new Administration();
            Hide();
            administration.Show();
        }
        private void UserMode_Click(object sender, RoutedEventArgs e)
        {
            UserFormWPF userFormWPF = new UserFormWPF();
            Hide();
            userFormWPF.Show();
        }
        private void UserMode_Copy_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }
        
        private void AboutDev_Click(object sender, RoutedEventArgs e)
        {
            DevWindMode devWindow = new DevWindMode();
            Hide();
            devWindow.Show();
        }
        
    }
}
