﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using Microsoft.Data.SqlClient;

namespace Prac._03
{
    /// <summary>
    /// Interaction logic for Administrator.xaml
    /// </summary>
    public partial class Administration : Window
    {
        static string Connection = "Server=.\\SQLEXPRESS; Database=PassAuthDB; Trusted_Connection=True; TrustServerCertificate=Yes";
        static DataTable dT = new DataTable("Користувачі системи");
        static int LenTable; static int index = LenTable - 1; static int count = 0;

        public Administration()
        {
            InitializeComponent();
            UpdateDataTable();
        }

        private void UpdatePasswd_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlConn = new SqlConnection(Connection);
            sqlConn.Open();
            String strQ;
            String RealPass = RealAdminPasswd.Password.ToString();
            String NewPass = NewAdminPasswd.Password.ToString();
            String NewPass2 = NewAdminPasswd2.Password.ToString();
            if ((RealPass == AdminPasswd.Password.ToString()) && (NewPass != "")
            && (NewPass == NewPass2))
            {
                if (sqlConn.State == System.Data.ConnectionState.Open)
                {
                    strQ = "UPDATE MainTable SET Password ='" + NewPass + "' WHERE Login = 'ADMIN'; ";
                    SqlCommand Com = new SqlCommand(strQ, sqlConn);
                    Com.ExecuteNonQuery();
                }
            }
            else
            {
                MessageBox.Show("Error!");
            }
            sqlConn.Close();
        }

        void UpdateDataTable()
        {
            SqlConnection sqlConn = new SqlConnection(Connection);
            sqlConn.Open();
            if (sqlConn.State == System.Data.ConnectionState.Open)
            {
                SqlDataAdapter Data = new SqlDataAdapter("SELECT Name, Surname, Login, Status, Restriction FROM MainTable", sqlConn);

                dT = new DataTable("Користувачі системи");
                Data.Fill(dT);
                AllUsersDG.ItemsSource = dT.DefaultView;
                LenTable = dT.Rows.Count;
                UsersLogins.ItemsSource = dT.AsEnumerable().Select(r => r.Field<String>("Login")).ToList();
            }
            sqlConn.Close();

        }

        private void Prev_Click(object sender, RoutedEventArgs e)
        {
            if (index > 0)
            {
                index--;
                UserNameSelected.Content = dT.Rows[index][0].ToString();
                UserSurnameSelected.Content = dT.Rows[index][1].ToString();
                UserLoginSelected.Content = dT.Rows[index][2].ToString();
                UserStatusSelected.Content = dT.Rows[index][3].ToString();
                UserRestrictionSelected.Content = dT.Rows[index][4].ToString();
            }
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            if (index < LenTable - 1)
            {
                index++;
                UserNameSelected.Content = dT.Rows[index][0].ToString();
                UserSurnameSelected.Content = dT.Rows[index][1].ToString();
                UserLoginSelected.Content = dT.Rows[index][2].ToString();
                UserStatusSelected.Content = dT.Rows[index][3].ToString();
                UserRestrictionSelected.Content = dT.Rows[index][4].ToString();
            }
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlConn = new SqlConnection(Connection);
            sqlConn.Open();
            String strQ;
            String UserLogin = AddingUserLogin.Text;
            try
            {
                if (sqlConn.State == System.Data.ConnectionState.Open)
                {
                    strQ = "INSERT INTO MainTable (Name, Surname, Login, Status, Restriction) values('', '', '" + UserLogin + "', 1, 0); ";
                    SqlCommand Com = new SqlCommand(strQ, sqlConn);
                    Com.ExecuteNonQuery();
                }
                UpdateDataTable();
            }
            catch
            {
                MessageBox.Show("Користувача не додано! Можливо такий в базі вже є!");
            }
            sqlConn.Close();
        }

        private void CorrectStatusBtn_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlConn = new SqlConnection(Connection);
            sqlConn.Open();
            String strQ;
            bool UserStatus = (bool)ChangeActive.IsChecked;
            if (sqlConn.State == System.Data.ConnectionState.Open)
            {
                strQ = "UPDATE MainTable SET Status ='" + UserStatus + "' WHERE Login='" +
                UsersLogins.SelectedValue.ToString() + "';";
                SqlCommand Com = new SqlCommand(strQ, sqlConn);
                Com.ExecuteNonQuery();
            }
            sqlConn.Close();
            UpdateDataTable();
        }

        private void CorrectRestrictionBtn_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlConn = new SqlConnection(Connection);
            sqlConn.Open();
            String strQ;
            bool UserRestriction = (bool)ChangeRestriction.IsChecked;
            if (sqlConn.State == System.Data.ConnectionState.Open)
            {
                strQ = "UPDATE MainTable SET Restriction ='" + UserRestriction + "' WHERE Login = '" + UsersLogins.SelectedValue.ToString() + "'; ";
                SqlCommand Com = new SqlCommand(strQ, sqlConn);
                Com.ExecuteNonQuery();
            }
            sqlConn.Close();
            UpdateDataTable();
        }
        private void ExitFromSystem_Click(object sender, RoutedEventArgs e)
        {
            RealAdminPasswd.Password = ""; RealAdminPasswd.IsEnabled = false;
            NewAdminPasswd.Password = ""; NewAdminPasswd.IsEnabled = false;
            NewAdminPasswd2.Password = ""; NewAdminPasswd2.IsEnabled = false;
            Prev.IsEnabled = false; Next.IsEnabled = false;
            UpdatePasswd.IsEnabled = false;
            AddUser.IsEnabled = false;
            CorrectStatusBtn.IsEnabled = false;
            CorrectRestrictionBtn.IsEnabled = false;
            AdminPasswd.Password = "";
            UsersLogins.ItemsSource = "";
        }
        Boolean RestrictionFunc(String Pass)
        {
            Byte Count1, Count2, Count3;
            Byte LenPass = (Byte)Pass.Length;
            Count1 = Count2 = Count3 = 0;
            for (Byte i = 0; i < LenPass; i++)
            {
                if ((Convert.ToInt32(Pass[i]) >= 65) &&

                (Convert.ToInt32(Pass[i]) <= 65 + 25))

                    Count1++;
                if ((Convert.ToInt32(Pass[i]) >= 97) &&

                (Convert.ToInt32(Pass[i]) <= 97 + 25))

                    Count2++;
                if ((Pass[i] == '+') || (Pass[i] == '-') || (Pass[i] == '*') ||

                (Pass[i] == '/'))

                    Count3++;
            }
            return (Count1 * Count2 * Count3 != 0);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }

        private void AutorBtn_Click(object sender, RoutedEventArgs e)
        {
            String passwd = AdminPasswd.Password;
            SqlConnection sqlConn = new SqlConnection(Connection);

            sqlConn.Open();
            if (sqlConn.State == System.Data.ConnectionState.Open)
            {
                String strQ = "SELECT * FROM MainTable WHERE Password='" + passwd + "';";
                SqlDataAdapter Data = new SqlDataAdapter(strQ, sqlConn);
                dT = new DataTable("Користувачі системи");
                Data.Fill(dT);
                if (dT.Rows.Count == 0)
                {
                    count++;

                    String s = "Невірно введений пароль! " +

                    "Помилкове введення No" + count.ToString();

                    MessageBox.Show(s);
                    if (count == 3)
                        System.Windows.Application.Current.Shutdown();
                }
                else if (dT.Rows[0][3].ToString() == passwd)
                {
                    RealAdminPasswd.IsEnabled = true;
                    NewAdminPasswd.IsEnabled = true;
                    NewAdminPasswd2.IsEnabled = true;
                    Prev.IsEnabled = true;
                    Next.IsEnabled = true;
                    AddUser.IsEnabled = true;
                    ChangeActive.IsEnabled = true;
                    ChangeRestriction.IsEnabled = true;
                    CorrectStatusBtn.IsEnabled = true;
                    CorrectRestrictionBtn.IsEnabled = true;
                    AddingUserLogin.IsEnabled = true;
                    UpdatePasswd.IsEnabled = true;
                    UpdateDataTable();
                }
            }
            sqlConn.Close();
        }
    }
}
