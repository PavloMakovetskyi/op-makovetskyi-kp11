﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StatOpsLib
{
    public class StatOpsClass
    {
        public static double currAlpha = 0.05;
        const int DEGREES = 5;
        public static double tableStudent;

        public double Expectation(List<double> currList) => currList.AsQueryable().Sum() / (currList.Count - 1);
        public double Variance(List<double> currList)
        {
            double expectation = Expectation(currList);
            double variance = 0;
            foreach (var item in currList)
                variance += (item - expectation) * (item - expectation);
            variance /= currList.Count - 1;
            return variance;
        }
        public double StandardDeviance(double variance) => (double)Math.Sqrt(variance);

        public double CoefStudent(double expect, double deviance, double nDash, double currElem)
        => Math.Abs(currElem - expect) / Math.Abs(deviance / Math.Sqrt(nDash));

        public double CoefFisher(double FirstVariance, double SecondVariance)
        => Math.Max(FirstVariance, SecondVariance) / Math.Min(FirstVariance, SecondVariance);


    }
}