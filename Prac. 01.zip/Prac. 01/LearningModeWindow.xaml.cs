﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;
using StatOpsLib;

public static class GlobVars
{
    public static double etalonVariance;
    public static double tempVariance;
    static List<double> rawIntervals; static List<double> copyRaw;
    static List<double> etalonIntervals; 
}

namespace AuthCheckingWPF
{
    public partial class LearningMode : Window
    {
        
        
        Stopwatch sw = new Stopwatch();
        StatOpsClass statOps = new StatOpsClass();

        static int repeats = 0;
        static double currAlpha;
        const int DEGREES = 5;
        static double tableStudent;
        
        public LearningMode()
        {
            InitializeComponent();
            if (File.Exists("interData.txt"))
                File.Delete("interData.txt");
            if (File.Exists("filtData.txt"))
                File.Delete("filtData.txt");
            if (File.Exists("statData.txt"))
                File.Delete("statData.txt");
            
            ProtectionMode pm = new ProtectionMode();
            

            currAlpha = double.Parse(pm.AlphaSelector.Text);
            switch (currAlpha) 
            {
                case 0.2:
                    tableStudent = 0.919544;
                    break;
                case 0.1:
                    tableStudent = 1.475844;
                    break;
                case 0.05:
                    tableStudent = 2.015048;
                    break;
                case 0.02:
                    tableStudent = 2.570582;
                    break;
                case 0.01:
                    tableStudent = 3.364930;
                    break;
                case 0.005:
                    tableStudent = 4.032143;
                    break;
                case 0.002:
                    tableStudent = 5.794351;
                    break;
                case 0.001:
                    tableStudent = 5.893430;
                    break;
                default:
                    tableStudent = 2.015048;
                    break;
            }

        }

        private void CloseStudyMode_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            LearningModeWindow.Hide();
            window.Show();
        }

        private void TextBox_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (!sw.IsRunning)
            {
                sw.Reset();
                sw.Start();
            }
            else
            {
                sw.Stop();
                string watchIter = sw.Elapsed.TotalSeconds.ToString();
                GlobVars.rawIntervals.Add(double.Parse(watchIter));
                copyRaw.Add(double.Parse(watchIter));
                sw.Restart();
            }

            SymbolCount.Content = InputField.Text.Length.ToString();

            if (InputField.Text.Length >= VerifField.Text.Length)
            {
                repeats++;
                SymbolCount.Content = "0";
                
               
                using (StreamWriter streamWriter1 = new StreamWriter("interData.txt", true))
                {
                    foreach (var interval in copyRaw) { streamWriter1.Write(interval.ToString() + " "); }
                    streamWriter1.WriteLine();
                    copyRaw.Clear();
                }
                sw.Stop();

                if (repeats >= Convert.ToInt32(CountProtection.Text))
                {
                    InputField.Text = "Input finished!";
                    sw.Reset();
                    sw.Stop();
                    repeats = 0;
                    using (StreamWriter streamWriter2 = new StreamWriter("filtData.txt", true))
                    {
                        Filtering(rawIntervals);
                        foreach (var interval in filteredIntervals) {streamWriter2.WriteLine(interval);}
                        GlobVars.etalonVariance = statOps.Variance(filteredIntervals);
                        rawIntervals.Clear();
                        filteredIntervals.Clear();
                    }
                }
                else InputField.Text = string.Empty;
            }
        }
        void Filtering(List<double> currentIntervalSet)
        {
            List<double> copySet = currentIntervalSet;
            
            double Expectation; double nDash = currentIntervalSet.Count - 1;
            double Variance;
            double StandardDeviation;
            double CoefStudent;

            for (int i = 0; i < nDash; i++) 
            {
                var currElem = copySet[i];
                copySet.RemoveAt(i);
                Expectation = statOps.Expectation(copySet);
                Variance = statOps.Variance(copySet);
                StandardDeviation = statOps.StandardDeviance(Variance);
                CoefStudent = statOps.CoefStudent(Expectation, StandardDeviation, nDash, currElem);
                if (!(CoefStudent > tableStudent)) filteredIntervals.Add(currElem);
                copySet.Insert(i, currElem);
            }
        }
    }
}
