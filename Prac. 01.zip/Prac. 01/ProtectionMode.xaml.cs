﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;
using StatOpsLib;

namespace AuthCheckingWPF
{
    /// <summary>
    /// Interaction logic for ProtectionMode.xaml
    /// </summary>
    public partial class ProtectionMode : Window
    {

        static List<double> rawIntervals = new List<double>();
        static int repeats = 0;
        static double currAlpha;
        const double tableFisher = 4.21;
        Stopwatch sw = new Stopwatch();

        StatOpsClass statOps = new StatOpsClass();

        public ProtectionMode()
        {
            InitializeComponent();
            currAlpha = double.Parse(AlphaSelector.Text);


        }

        private void CloseStudyMode_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            ProtectionModeWindow.Hide();
            window.Show();
        }

        private void TextBox_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (!sw.IsRunning)
            {
                sw.Reset();
                sw.Start();
            }
            else
            {
                sw.Stop();
                string watchIter = sw.Elapsed.TotalSeconds.ToString();
                rawIntervals.Add(double.Parse(watchIter));
                sw.Restart();
            }

            SymbolCount.Content = InputField.Text.Length.ToString();

            if (InputField.Text.Length >= VerifField.Text.Length)
            {
                repeats++;
                SymbolCount.Content = "0";
                sw.Stop();

                if (repeats >= Convert.ToInt32(CountProtection.Text))
                {
                    InputField.Text = "Input finished!";
                    sw.Reset();
                    sw.Stop();
                    repeats = 0;
                    Variances.tempVariance = statOps.Variance(rawIntervals);

                    if (statOps.CoefFisher(Variances.tempVariance, Variances.etalonVariance) <= tableFisher)
                        DispField.Content = "Однорідні";
                    else
                        DispField.Content = "Неоднорідні";
                }
                else InputField.Text = string.Empty;
            }
        }
    }
}
