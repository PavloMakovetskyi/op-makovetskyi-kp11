﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Prac02
{
	public static class RandomProvider
	{
		private static readonly Random _random = new Random();

		public static int GetRandomValue(int limit)
		{
			return _random.Next(limit);
		}

		public static Location[] GetRandomDestinations(int count)
		{
			if (count < 2)
				throw new ArgumentOutOfRangeException("Only one city");

			Location[] result = new Location[count];
			for(int i=0; i<count; i++)
			{
				int x = GetRandomValue(700) + 50;
				int y = GetRandomValue(500) + 50;
				result[i] = new Location(x, y);
			}

			return result;
		}

		public static void MutateRandomLocations(Location[] locations)
		{
			if (locations == null)
				throw new ArgumentNullException("No locations");

			if (locations.Length < 2)
				throw new ArgumentException("The locations array must have at least two items.");

			int mutationCount = GetRandomValue(locations.Length/10) + 1;
			for (int mutationIndex=0; mutationIndex<mutationCount; mutationIndex++)
			{
				int index1 = GetRandomValue(locations.Length);
				int index2 = GetRandomValue(locations.Length-1);
				if (index2 >= index1)
					index2++;

				switch(GetRandomValue(3))
				{
					case 0: Location.SwapLocations(locations, index1, index2); break;
					case 1: Location.MoveLocations(locations, index1, index2); break;
					case 2: Location.ReverseRange(locations, index1, index2); break;
					default: throw new InvalidOperationException();
				}
			}
		}

		public static void FullyRandomizeLocations(Location[] locations)
		{
			if (locations == null)
				throw new ArgumentNullException("No locations");

			int count = locations.Length;
			for (int i = count - 1; i > 0; i--)
			{
				int value = GetRandomValue(i + 1);
				if (value != i)
					Location.SwapLocations(locations, i, value);
			}
		}

		internal static void _CrossOver(Location[] locations1, Location[] locations2, bool mutateFailedCrossovers)
		{
			var availableLocations = new HashSet<Location>(locations1);

			int startPosition = GetRandomValue(locations1.Length);
			int crossOverCount = GetRandomValue(locations1.Length - startPosition);

			if (mutateFailedCrossovers)
			{
				bool useMutation = true;
				int pastEndPosition = startPosition + crossOverCount;
				for (int i=startPosition; i<pastEndPosition; i++)
				{
					if (locations1[i] != locations2[i])
					{
						useMutation = false;
						break;
					}
				}

				if (useMutation)
				{
					MutateRandomLocations(locations1);
					return;
				}
			}

			Array.Copy(locations2, startPosition, locations1, startPosition, crossOverCount);
			List<int> toReplaceIndexes = null;

			int index = 0;
			foreach(var value in locations1)
			{
				if (!availableLocations.Remove(value))
				{
					if (toReplaceIndexes == null)
						toReplaceIndexes = new List<int>();

					toReplaceIndexes.Add(index);
				}

				index++;
			}


			if (toReplaceIndexes != null)
			{
                
				using(var enumeratorIndex = toReplaceIndexes.GetEnumerator())
				{
					using(var enumeratorLocation = availableLocations.GetEnumerator())
					{
						while(true)
						{
							if (!enumeratorIndex.MoveNext())
							{
								Debug.Assert(!enumeratorLocation.MoveNext());
								break;
							}

							if (!enumeratorLocation.MoveNext())
								throw new InvalidOperationException("Something wrong happened.");

							locations1[enumeratorIndex.Current] = enumeratorLocation.Current;
						}
					}
				}
			}
		}
	}
}
