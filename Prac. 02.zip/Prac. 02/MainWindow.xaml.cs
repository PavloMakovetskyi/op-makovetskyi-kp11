﻿using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Collections.Generic;
using System.Windows.Controls;

namespace Prac02
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private int _destinationCount = 20;
		private const int _populationCount = 114;
		private bool _closing;
		static int time;
		

		private readonly Location _startLocation = new Location(50, 50);
		private readonly object _algorithmLock = new object();
		private TravellingSalesmanAlgorithm _algorithm;
		private Location[] _randomLocations;
		public MainWindow()
		{
			InitializeComponent();
			int time = int.Parse(TimeStutter.Text);

			buttonMoreDestinations.Click += new RoutedEventHandler(buttonMoreDestinations_Click);
			buttonLessDestinations.Click += new RoutedEventHandler(buttonLessDestinations_Click);

			_randomLocations = RandomProvider.GetRandomDestinations(_destinationCount);
			_algorithm = new TravellingSalesmanAlgorithm(_startLocation, _randomLocations, _populationCount);

			_bestSolutionSoFar = _algorithm.GetBestSolutionSoFar().ToArray();
			_DrawLines();

			var thread = new Thread(_Thread);
			thread.Start();
		}


		private void _AdjustDestinations()
		{
			labelDestinationCount.Text = _destinationCount.ToString() + " ";
			buttonMoreDestinations.IsEnabled = _destinationCount < 57;
			buttonLessDestinations.IsEnabled = _destinationCount > 6;

			_randomLocations = RandomProvider.GetRandomDestinations(_destinationCount);

			lock(_algorithmLock)
				_algorithm = new TravellingSalesmanAlgorithm(_startLocation, _randomLocations, _populationCount);

			_bestSolutionSoFar = _algorithm.GetBestSolutionSoFar().ToArray();
			_DrawLines();
		}
		void buttonMoreDestinations_Click(object sender, RoutedEventArgs e)
		{
			if (!buttonMoreDestinations.IsEnabled)
				return;

			_destinationCount++;

			_AdjustDestinations();
		}

		void buttonLessDestinations_Click(object sender, RoutedEventArgs e)
		{
			if (!buttonLessDestinations.IsEnabled)
				return;

			_destinationCount--;

			_AdjustDestinations();
		}

		void buttonNewDestinations_Click(object sender, RoutedEventArgs e)
		{
			_randomLocations = RandomProvider.GetRandomDestinations(_destinationCount);

			lock(_algorithmLock)
				_algorithm = new TravellingSalesmanAlgorithm(_startLocation, _randomLocations, _populationCount);

			_bestSolutionSoFar = _algorithm.GetBestSolutionSoFar().ToArray();
			_DrawLines();
		}

		void buttonResetSearch_Click(object sender, RoutedEventArgs e)
		{
			lock(_algorithmLock)
				_algorithm = new TravellingSalesmanAlgorithm(_startLocation, _randomLocations, _populationCount);

			_bestSolutionSoFar = _algorithm.GetBestSolutionSoFar().ToArray();
			_DrawLines();
		}

		private readonly object _lock = new object();
		private Location[] _bestSolutionSoFar;
		private bool _messageWaitingToBeProcessed;
		private volatile bool _mutateFailedCrossovers = false;
		private volatile bool _mutateDuplicates = false;
		private volatile bool _mustDoCrossovers = true;
		private void _Thread()
		{
			while(!_closing)
			{
				lock(_algorithmLock)
				{
					_algorithm.MustMutateFailedCrossovers = _mutateFailedCrossovers;
					_algorithm.MustDoCrossovers = _mustDoCrossovers;
					_algorithm.Reproduce();

					if (_mutateDuplicates)
						_algorithm.MutateDuplicates();

					var newSolution = _algorithm.GetBestSolutionSoFar().ToArray();
					if (!newSolution.SequenceEqual(_bestSolutionSoFar))
					{
						lock(_lock)
						{
							_bestSolutionSoFar = newSolution;

							if (!_messageWaitingToBeProcessed)
							{
								_messageWaitingToBeProcessed = true;

								Dispatcher.BeginInvoke(new Action(_DrawLines), DispatcherPriority.ApplicationIdle);
							}
						}
						Thread.Sleep(100);
					}
				}
			}
		}

		private void _DrawLines()
		{
			Location[] bestSolutionSoFar;
			lock(_lock)
			{
				_messageWaitingToBeProcessed = false;
				bestSolutionSoFar = _bestSolutionSoFar;
			}

			labelDistance.Content = (long)Location.GetTotalDistance(_startLocation, bestSolutionSoFar);

			var canvasChildren = canvas.Children;
			canvasChildren.Clear();

			var actualLocation = _startLocation;
			int index = 0;
			foreach (var destination in _AddEndLocation(bestSolutionSoFar))
			{
				int red = 255 * index / bestSolutionSoFar.Length;
				int blue = 255 - red;

				var line = new Line();
				var color = Color.FromRgb((byte)red, 0, (byte)blue);
				line.Stroke = new SolidColorBrush(color);
				line.X1 = actualLocation.X;
				line.Y1 = actualLocation.Y;
				line.X2 = destination.X;
				line.Y2 = destination.Y;
				canvasChildren.Add(line);

				var circle = new Ellipse();
				circle.Stroke = Brushes.Black;
				circle.Fill = Brushes.Blue;

				circle.Width = 11;
				circle.Height = 11;
				Canvas.SetLeft(circle, destination.X - 5);
				Canvas.SetTop(circle, destination.Y - 5);
				Panel.SetZIndex(circle, 57);
				canvasChildren.Add(circle);

				actualLocation = destination;
				index++;
			}
		}

		private IEnumerable<Location> _AddEndLocation(Location[] middleLocations)
		{
			foreach(var location in middleLocations)
				yield return location;

			yield return _startLocation;
		}

		protected override void OnClosed(EventArgs e)
		{
			OnClosed(e);
			_closing = true;
		}
	}
}
